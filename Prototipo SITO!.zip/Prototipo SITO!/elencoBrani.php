<html>
  <head>
  </head>
  
  <body>
	<?php
		//CONNESSIONE AL DATABASE
		@include("connessioneDB.php");
		
		/*$link = mysqli_connect("localhost","root");
		  
		if(mysqli_connect_errno())
		{
			printf("Connessione Fallita");
			exit();
		}*/
		
	
		mysqli_select_db($link,"jukeboxsql");
		
		
		$idAlbum=$_POST['ID'];
		$query = "SELECT * FROM brani join album on CodAlbum='$idAlbum'";
		$result = mysqli_query($link,$query);
		if (!$result) 
		{
			echo "query non eseguita " . mysqli_error();
			exit;
		}

		if (mysqli_num_rows($result) == 0) 
		{
				echo "nessun record trovato";
				exit;
		}
		while ($row = mysqli_fetch_assoc($result)) 
		{
				echo "titolo:".$row["titolo"]; 
				echo "durata:".$row["durata"];	  
				
				
		}
		
		
		mysqli_close($link);	
		
		?>
  </body>
</html>