<?php
	//CONNESSIONE AL DATABASE
	@include("connessioneDB.php");
	
	/*$link = mysqli_connect("localhost","root");
	  
	if(mysqli_connect_errno())
	{
		printf("Connessione Fallita");
		exit();
	}*/
	

	mysqli_select_db($link,"jukeboxsql");
	
	$canzone=idcanzone;
	
	$query = "INSERT INTO coda (IDBrano)
					VALUES ('$canzone')";
	$result = mysqli_query($link,$query);
	if (!$result) 
	{
		echo "query non eseguita " . mysqli_error();
		exit;
	}

	
	mysqli_close($link);	
	
?> 