<!doctype html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Waterwheel Carousel Demo</title>
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.waterwheelCarousel.js"></script>
    <script type="text/javascript">
      $(document).ready(function () {
        var carousel = $("#carousel").waterwheelCarousel({
          flankingItems: 3,
          movingToCenter: function ($item) {
            $('#callback-output').prepend('movingToCenter: ' + $item.attr('id') + '<br/>');
          },
          movedToCenter: function ($item) {
            $('#callback-output').prepend('movedToCenter: ' + $item.attr('id') + '<br/>');
          },
          movingFromCenter: function ($item) {
            $('#callback-output').prepend('movingFromCenter: ' + $item.attr('id') + '<br/>');
          },
          movedFromCenter: function ($item) {
            $('#callback-output').prepend('movedFromCenter: ' + $item.attr('id') + '<br/>');
          },
          clickedCenter: function ($item) {
            $('#callback-output').prepend('clickedCenter: ' + $item.attr('id') + '<br/>');
          }
        });

        $('#prev').bind('click', function () {
          carousel.prev();
          return false
        });

        $('#next').bind('click', function () {
          carousel.next();
          return false;
        });

        $('#reload').bind('click', function () {
          newOptions = eval("(" + $('#newoptions').val() + ")");
          carousel.reload(newOptions);
          return false;
        });

      });
    </script>

    <style type="text/css">
	input[type="text"] {
		border-radius: 7px;
		-moz-border-radius: 8px; // Per Mozilla
		-webkit-border-radius: 8px; // Per chrome e safari
		behavior: url(PIE/PIE.htc); // Per IE
		border: 1px solid red;
		}
      body {
        font-family:Arial;
        font-size:12px;
         background: #333333;
      }
      .example-desc {
        margin:3px 0;
        padding:5px;
      }

      #carousel {
        width:100%;
        border:1px solid #222;
        height:550px;
        position:relative;
        clear:both;
        overflow:hidden;
        background:#FFF;
      }
      #carousel img {
        visibility:hidden; /* hide images until carousel can handle them */
        cursor:pointer; /* otherwise it's not as obvious items can be clicked */
      }

      .split-left {
        width:450px;
        float:left;
      }
      .split-right {
        width:400px;
        float:left;
        margin-left:10px;
      }
      #callback-output {
        height:250px;
        overflow:scroll;
      }
      textarea#newoptions {
        width:430px;
      }
	  #colonna1
	  {
	  
	  width:8%;
	  }
	  #colonna2
	  {
	  width:92%;
	  }
	  #menu{
		height:500px;
	  
	  }
    </style>
  </head>
  <body>
  <div align="Center" >
  <img src="images/JukeBox.png" />
  </div>
   <input type="text" name="Ricerca" size="12" placeholder="Ricerca" border="10" />
	<table width="100%"> 
	<tr>
	<td id= "colonna1" >
	<div id ="menu">
	<a href="PaginaBrani.html" align="Center" style="color:white" ><h1>Brani</h1></a>
	<h1 align="Center" style="color:white" >Album</h1>
	<a href="PaginaCantanti.html" align="Center" style="color:white" ><h1>Cantanti</h1></a>
	
	</div>
	</td>
	<td>
	<div id="carousel">
		<?php
			include connect('connessione.php');
			$query = "select * from brani";
			$res = mysqli_query($query);
			
			while(  $row = mysqli_fetch_object($res)  )
			{
				$target = " window.location.href='indexAlbum.php?id=$row->id'";
				echo "<img src='$row->immagine' id='$row->id'      ondblclick='$target'    />"
			}
		?>
    </div>
	</td>
	
	</tr>
	
	</table>
	
    
    
	
	
    <!-- <a href="#" id="prev">Prev</a> | <a href="#" id="next">Next</a> -->

    <br/>

  
    
    </div>

  </body>
</html>

