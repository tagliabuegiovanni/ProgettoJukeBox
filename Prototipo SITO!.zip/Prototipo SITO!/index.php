<!doctype html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Juke Box Demo</title>
	<link rel="stylesheet" type="text/css" href="stile.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.waterwheelCarousel.js"></script>
    <script type="text/javascript">
	function aggiornaDivElencoBrani(album){
			//Chiamata AJAX
			//la pagina ElencoBrani.php riceve  $_POST['nomeAlbum'] oppure   $_POST['nomeArtista']
			$.post( "elencoBrani.php", { ID: album })
			  .done(function( data ) {
				$("#divElencoBrani").html(data); 
			  });
		}
      $(document).ready(function () {
        var carousel = $("#carousel").waterwheelCarousel({
          flankingItems: 3,
          movingToCenter: function ($item) {
            $('#callback-output').prepend('movingToCenter: ' + $item.attr('id') + '<br/>');
          },
          movedToCenter: function ($item) {
            $('#callback-output').prepend('movedToCenter: ' + $item.attr('id') + '<br/>');
          },
          movingFromCenter: function ($item) {
            $('#callback-output').prepend('movingFromCenter: ' + $item.attr('id') + '<br/>');
          },
          movedFromCenter: function ($item) {
            $('#callback-output').prepend('movedFromCenter: ' + $item.attr('id') + '<br/>');
          },
          clickedCenter: function ($item) {
            $('#callback-output').prepend('clickedCenter: ' + $item.attr('id') + '<br/>');
          }
        });

        $('#prev').bind('click', function () {
          carousel.prev();
          return false
        });

        $('#next').bind('click', function () {
          carousel.next();
          return false;
        });

        $('#reload').bind('click', function () {
          newOptions = eval("(" + $('#newoptions').val() + ")");
          carousel.reload(newOptions);
          return false;
        });

      });
    </script>

</head>
  <body>
  <div align="Center" >
	<img src="images/JukeBox.png" />
  </div>
  
  <div>
   <input type="text" name="Ricerca" size="17" placeholder="Ricerca" border="10" />
	</div> 
 
	<div id ="menu">
		<a href="PaginaBrani.php" align="Center" style="color:white" ><h1>Brani</h1></a>
		<h1 align="Center" style="color:white" >Album</h1>
		<a href="PaginaCantanti.html" align="Center" style="color:white" ><h1>Cantanti</h1></a>
	</div>

	<div id="carousel">
	<?php
			include 'connessioneDB.php';
			
			mysqli_select_db($link,"jukeboxsql");
			
			$query = "select * from album";
			$result = mysqli_query($link,$query);
			//ID`, `linkAudio`, `durata`, `linkImg`, `titolo`
			
			while(  $row = mysqli_fetch_object($result)  )
			{
				//<img src="images/brani/coldplay-magic.jpg" id="item-2" ondblclick="window.location.href='index.html'" />  -->
				
				//$target = " window.location.href='indexAlbum.php?id=$row->ID'";
				//echo "<img src='$row->linkImg' id='$row->ID'      ondblclick='$target'    />";
				//echo "<img src='$row->linkImg' id='$row->ID'/>";
				echo "<img src='$row->linkImg' id='$row->ID' ondblclick='aggiornaDivElencoBrani($row->ID);' />";
				
				//echo "<img src='$row->linkImg' id='$row->ID' ondblclick='alert(\"$row->linkImg\");'    />";
			}
			mysqli_close($link);
		?>	
   
	</div>

 
	<div id="divElencoBrani">
		Elenco...
	</div>
 
	
	</tr>
	
	</table>
	
    
    
	
	
    <!-- <a href="#" id="prev">Prev</a> | <a href="#" id="next">Next</a> -->

    <br/>

  
    
    </div>

  </body>
</html>

