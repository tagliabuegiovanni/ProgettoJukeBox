﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace riproduttoreMusicale
{
    public partial class Form1 : Form
    {
        System.Timers.Timer t1 = new System.Timers.Timer();
        connection c1 = new connection();
        public Form1()
        {
            InitializeComponent();
            t1.Interval = 10000;
            t1.BeginInit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            MediaPlayer.URL=@"D:\PROGETTO\music\Alvaro Soler - Sofia.mp3"; 
            
        }

        private void MediaPlayer_Enter(object sender, EventArgs e)
        {
            MediaPlayer.URL = @"D:\PROGETTO\music\Alvaro Soler - Sofia.mp3";
            MessageBox.Show(c1.Ricerca(), "", MessageBoxButtons.OK);
        }
    }
}
