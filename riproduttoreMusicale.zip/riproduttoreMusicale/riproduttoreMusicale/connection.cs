﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
//using System.Windows.Forms;
using System.Drawing;
using System.Security.Cryptography;

namespace riproduttoreMusicale
{
    public class connection
    {
        MySqlConnection mcon = new MySqlConnection("server = localhost; user id = root; database = jukebox; password= '';port=3306");
        MySqlCommand mcd;
        MySqlDataReader mdr;

        public void ApriConnessione()
        {
            if (mcon.State == ConnectionState.Closed)
            {
                mcon.Open();
            }
        }

        public void ChiudiConnessione()
        {
            if (mcon.State == ConnectionState.Open)
            {
                mcon.Close();
            }
        }

        public void ExecuteQuery(string q)
        {
            ApriConnessione();
            try
            {
                mcd = new MySqlCommand(q, mcon);
                if (mcd.ExecuteNonQuery() == 1)
                {
                    //MessageBox.Show("Query Eseguita");
                    Console.WriteLine("Query Eseguita");
                }
                else
                {
                    //MessageBox.Show("Query Non Eseguita");
                    Console.WriteLine("Query non Eseguita");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                //MessageBox.Show(ex.Message);
            }
            finally
            {
                mcon.Close();
            }
        }

        public string Ricerca()
        {
            ApriConnessione();
            string query = "SELECT ID FROM coda";
            string risultato = "not found";
            mcd = new MySqlCommand(query, mcon);
            mdr = mcd.ExecuteReader();
           
            bool trovata = false;
            while (mdr.Read())
            {
                trovata = true;
                break;
            }
            
           /*if(trovata)
            {
                risultato = mdr["linkAudio"].ToString();
            }*/
           
            ChiudiConnessione();
            return risultato;
        }
    }
}
