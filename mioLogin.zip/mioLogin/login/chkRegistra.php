<html>
  <head></head>
  <?php session_start(); ?>
  <body>
	<?php
		//CONNESSIONE AL DATABASE
		@include("connessioneDB.php");
		
		/*$link = mysqli_connect("localhost","root");
		  
		if(mysqli_connect_errno())
		{
			printf("Connessione Fallita");
			exit();
		}*/
	
		mysqli_select_db($link,"cinema");
		
		//CONTROLLO CHE NON CI SIA GIA L'UTENTE
		$name = $_POST['UsNa'];
		$psw = md5($_POST['Psw1']);	
		
		$query1 = "SELECT * FROM utenti utenti
		WHERE Username = '$name'";
		
		$result = mysqli_query($link,$query1);
		
		if(mysqli_num_rows($result) > 0 )
		{
			echo "utente gia inserito";
			$_SESSION["ESISTE"]="si";
		}		
		else
		{
			$query2 = "INSERT INTO utenti (Username,Password)
			VALUES ('$name','$psw')";
			$result = mysqli_query($link,$query2);
			
			echo "utente inserito";
			
		}		
		
		mysqli_close($link);
		
		header("location: Login.php");
	  ?>
  </body>
</html>

