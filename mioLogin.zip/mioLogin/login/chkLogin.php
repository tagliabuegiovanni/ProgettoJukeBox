<html>
  <head></head>
  <?php session_start(); ?>
  <body>
    <?php
		unset($SESSION["utente"]);
		
		//CONNESSIONE AL DATABASE
		@include("connessioneDB.php");
		
		//leggo user e password di login
		$nome=$_POST['UsNaL'];
		$password = md5($_POST['Psw1L']);
		
	    	
		//COSTRUISCO LA QUERY
		mysqli_select_db($link,"cinema");

		$query = "SELECT Username FROM utenti WHERE Username = '$nome' AND Password = '$password'";
		$result = mysqli_query($link,$query);
		 
		
		if($row = mysqli_fetch_array($result,MYSQL_BOTH))
		{
			echo "Setto la sessione";
			$_SESSION["utente"] = $nome;
			//vado al menu
			header("location: menu.php");
		}
		else
		{
			//vado alla Login
			header("location: Login.php");
		}
			
		mysqli_close($link);
			
	  ?>
  </body>
</html>

