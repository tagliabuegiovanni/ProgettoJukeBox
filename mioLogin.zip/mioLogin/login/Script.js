function SiRegNoLog()
{
    document.getElementById('registrazione').hidden = false;
    document.getElementById('login').hidden = true;
}

function NoRegSiLog() {
    if(ControllaPSW()==true)
    {
        document.getElementById('registrazione').hidden = true;
        document.getElementById('login').hidden = false;
    }
    
}

function ControllaPSW(){

    if (document.getElementById('psw1').value != document.getElementById('psw2').value) {

        alert("I campi Password non corrispondono! impossibile proseguire");

        document.getElementById('psw2').focus();
        return false;
    }
    
    return true; 

}



