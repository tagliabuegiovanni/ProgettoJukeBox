<html>
	<head>
        <title>Benvenuto</title>
        <link href="stileLogin.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="Script.js"></script>
		<?php session_start(); 
		if(isset($_SESSION["ESISTE"]))
		{
			echo "<SCRIPT>alert('utente gia registrato');</SCRIPT>";
			unset($_SESSION["ESISTE"]);
		}
		
		?>
	</head>
	<body>
	<?php
	
	
	?>
	<div id="registrazione" hidden="hidden" >
        <form id="form1" action="CheckReg.php" method="POST" onsubmit="javascript: return ControllaPSW(); NoRegSiLog();" >
            <div id="reg">Registrazione</div>
            </br>
            <label id="R_user" >Username* :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="Text" name="UsNa" required size="20" /></label></br>
            </br>
            <label id="R_psw1" >Password* :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="Password" id="psw1" name="Psw1" required size="20" /></label></br>
            </br>
            <label id="R_psw2">Reinserisci Password* : <input type="Password" id="psw2" name="Psw2" required maxlength="25" size="20" /></label></br>
            </br>
            <label>* informazioni obbligatorie</label></br></br>
            <input type="Submit" value="Registrati" id="R_registrati"  /> &nbsp;&nbsp;<input type="button" value="Annulla" id="A_registrati" onclick="NoRegSiLog()" /></br>
        </form>
	</div>
	<div id="login" >
        <form id="form1" action="CheckLog.php" method="POST">
        <div id="reg">Accesso</div>
            </br>
            <label id="A_user">Username* :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="Text" name="UsNaL" required size="20" /></label></br>
            </br>
            <label id="A_psw">Password* &nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="password" name="Psw1L" required size="20" /></label></br>
            </br>
            * informazioni obbligatorie</br></br>
            <input type="Submit" value="Accedi" id="A_accedi" /> &nbsp;&nbsp; <input type="button" value="Registrati" id="A_registrati" onclick="SiRegNoLog()" /></br>
        </form>
	</div>
		
	</body>
</html>