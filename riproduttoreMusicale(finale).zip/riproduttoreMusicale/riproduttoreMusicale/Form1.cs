﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace riproduttoreMusicale
{
    public partial class Form1 : Form
    {
       // System.Timers.Timer t1 = new System.Timers.Timer();
        connection c1 = new connection();
        

        public Form1()
        {
            InitializeComponent();
           
        }

        

       private void MediaPlayer_Enter(object sender, EventArgs e)
        {
            MediaPlayer.URL = @c1.Ricerca();
            MessageBox.Show(c1.Ricerca(), "", MessageBoxButtons.OK);
        }

        private void MediaPlayer_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (MediaPlayer.playState==WMPLib.WMPPlayState.wmppsMediaEnded)
            {
                c1.delete();
                MediaPlayer.URL = @c1.Ricerca();
                MessageBox.Show(c1.Ricerca(), "", MessageBoxButtons.OK);
            }
        }

        /*private void MediaPlayer_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {

        }*/
    }
}
