<html>
<head>
	<link rel="stylesheet" href="stile.css">
	<title></title>

</head>

	<body >
	
	<div id="mainDiv">
		<div id="div1" >
			<?php
				include("connessioneDB.php");
				$query = "SELECT * FROM brani";
				
				$result = mysqli_query($conn,$query);
				
				if (!$result) 
				{
					echo "query non eseguita " . mysqli_error();
					exit;
				}

				if (mysqli_num_rows($result) == 0) 
				{
					echo "nessun record trovato";
					exit;
				}
				while ($row = mysqli_fetch_assoc($result)) 
				{
					echo "Titolo:".$row["titolo"]; 
					echo "<br/>";	
				}
			?>
		</div> 
		
		<div id="div2" >
			22232
		</div> 
		
		<div id="div3" >
			3333
		</div> 
	</div>
	</body>
</html>