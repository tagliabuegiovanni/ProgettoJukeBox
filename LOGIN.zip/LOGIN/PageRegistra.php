<html>
<head>
	<link rel="stylesheet" href="style.css">
	<script type="text/javascript" src="Script.js"></script>
</head>
	<body>
	<div class="login-page">
	  <div class="form">
		<form class="register-form">
		  <input type="text" placeholder="Nome"/>
		  <input type="password" placeholder="Password"/>
		  <input type="text" placeholder="Indirizzo Email"/>
		  <button>Registra</button>
		   <p class="message">Sei gi� registrato? <a href="login.php">Fai la Login</a></p>
		</form>
	  </div>		
	</div>	  
		
	</body>
</html>