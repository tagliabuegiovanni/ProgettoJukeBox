<html>
	<body>
		<?php
			$nome= $_POST['Nome'];
			$cognome= $_POST['Cognome'];
			$username= $_POST['Username'];
			$password= $_POST['Password'];
			
			$myfile= fopen("credenziali.txt","a")or die ("file non aperto");
			$txt = "$nome;$cognome;$username;$password"."\n";
			fwrite($myfile,$txt);
			fclose($myfile);
			
			echo "Registrazione effettuata con successo <br/>" ;
			echo "Riepilogo <br/>";
			echo "username $username password $password";
			
			
		?>
	</body>
</html>