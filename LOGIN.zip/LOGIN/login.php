<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" href="style.css">
	<script type="text/javascript" src="Script.js"></script>
</head>

	<body>
		<div class="login-page">
		<div class="form">
			<form class="login-form">
			  <input type="text" placeholder="username"/>
			  <input type="password" placeholder="password"/>
			  <button>login</button>
			  <p class="message">Non sei Registrato? <a href="PageRegistra.php"> <u> Registrati</u> </a></p>
			</form>
		</div>
		</div>
	</body>
</html>