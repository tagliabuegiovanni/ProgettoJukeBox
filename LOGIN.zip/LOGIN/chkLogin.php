<html>
	<body>
		<?php
			$username= $_POST['Username'];
			$password= $_POST['Password'];
			$myfile=fopen("credenziali.txt" , "r")or die ("file non aperto");
			//$testo="$username;$password"."\n";
			//fclose($myfile);
			$vettUtenti = file("credenziali.txt");
			foreach($vettUtenti as $riga )
			{
				$riga =STRPOS($stringa,";");
				$user=substr($stringa,0,$indice);
				$psw=substr($stringa,$indice+1); 
				
				if($username==$user && $password==trim($psw))
				{
					echo"Login eseguita con successo <br/>";
					echo "Ecco i tuoi dati <br/>";
					echo "Username $username Password $password";
				}
				else
				{
					echo "password o username errati";
				}
			}
			fclose($myfile);
		?>
	</body>
</html>