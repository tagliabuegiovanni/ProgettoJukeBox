<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" href="style.css">
</head>

	<body>
	<div class="divRegistra">
		<form action="chkRegistra.php" method="POST">
		<p id="divRegistrati">
			Nome= <input type="nome" name="Nome"/>
			</br></br>
			
			Cognome= <input type="cogn" name="Cognome"/>
			</br></br>
			
			Username= <input type="username" name="Username"/>
			</br></br>
			Password= <input type="password" name="Password" placeholder="password"/>
			</br></br></br>
			<button id="pulsante">Registrati</button>
			</br></br>
		<a href= "login.php"> Fai login </a>	
		</p >
		
		</form>
		
	</div>
	
	</body>
</html>