<?php

	//CONNESSIONE AL DATABASE
	$link = mysqli_connect("localhost","root");
	  
	if(mysqli_connect_errno())
	{
		printf("Connessione Fallita");
		exit();
	}

?>