function aggiornaDivElencoBrani(album,artista,txtRicerca){
			//Chiamata AJAX
			var strRicerca = "";
			if (txtRicerca!=null)
				strRicerca = txtRicerca.value;
			
			//la pagina ElencoBrani.php riceve  $_POST['nomeAlbum'] oppure   $_POST['nomeArtista']
			$.post( "elencoBrani.php", { IDAlbum: album , IDArtista: artista, ricerca: strRicerca})
			  .done(function( data ) {
				$("#divElencoBrani").html(data); 
			  });
		}
		
		//function per gli artisti
		
		
		function aggiornaDivCantante(album){
			//Chiamata AJAX
			//la pagina ElencoBrani.php riceve  $_POST['nomeAlbum'] oppure   $_POST['nomeArtista']
			$.post( "VisualizzaArtista.php", { ID: album })
			  .done(function( data ) {
				$("#divNomeArtista").html(data); 
			  });
		}
		function aggiornaDivAlbum(album){
			//Chiamata AJAX
			//la pagina ElencoBrani.php riceve  $_POST['nomeAlbum'] oppure   $_POST['nomeArtista']
			$.post( "VisualizzaDivAlbum.php", { ID: album })
			  .done(function( data ) {
				$("#divNomeAlbum").html(data); 
			  });
		}
		
		
      $(document).ready(function () {
        var carousel = $("#carousel").waterwheelCarousel({
          flankingItems: 3,
		  orientation: 'vertical',
		  separation: 100,
			//horizonOffset: 80,
		   opacityMultiplier: .4,
          movingToCenter: function ($item) {
			aggiornaDivElencoBrani($item.attr('id') );
			aggiornaDivCantante($item.attr('id') );
			aggiornaDivAlbum($item.attr('id') );
            $('#callback-output').prepend('movingToCenter: ' + $item.attr('id') + '<br/>');
          },
          movedToCenter: function ($item) {
            $('#callback-output').prepend('movedToCenter: ' + $item.attr('id') + '<br/>');
          },
          movingFromCenter: function ($item) {
            $('#callback-output').prepend('movingFromCenter: ' + $item.attr('id') + '<br/>');
          },
          movedFromCenter: function ($item) {
            $('#callback-output').prepend('movedFromCenter: ' + $item.attr('id') + '<br/>');
          },
          clickedCenter: function ($item) {
            $('#callback-output').prepend('clickedCenter: ' + $item.attr('id') + '<br/>');
          }
        });
		
		aggiornaDivElencoBrani(1);
		aggiornaDivCantante(1);
		aggiornaDivAlbum(1);

        $('#prev').bind('click', function () {
          carousel.prev();
          return false
        });

        $('#next').bind('click', function () {
          carousel.next();
          return false;
        });

        $('#reload').bind('click', function () {
          newOptions = eval("(" + $('#newoptions').val() + ")");
          carousel.reload(newOptions);
          return false;
        });

      });