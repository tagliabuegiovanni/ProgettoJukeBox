<?php		
   @include("connessioneDB.php");
	mysqli_select_db($link,"jukeboxsql");
	$idAlbum=$_POST['ID'];
	
	$query = "SELECT distinct a.nome as nomeArtista, alb.nome as nomeAlbum ".
			"from (artisti as a join brani as br on a.ID=br.CodArtista)".
			"		join album as alb on br.CodAlbum=alb.ID ".
			"WHERE alb.ID=$idAlbum";
			$result = mysqli_query($link,$query);
	if (!$result) 
	{
		echo "query non eseguita " . mysqli_error($link);
		exit;
	}

	if (mysqli_num_rows($result) == 0) 
	{
			echo "nessun record trovato";
			exit;
	}
	echo"Album: ";
	while ($row = mysqli_fetch_assoc($result)) 
	{
			
			
			echo $row["nomeAlbum"]. " ";
			
	}
	
	
	
?>

