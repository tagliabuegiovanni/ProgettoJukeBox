<!doctype html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=320,initial-scale=1" />
    <title>JukeBox 2.0</title>
	<link rel="stylesheet" type="text/css" href="stile.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.waterwheelCarousel.js"></script>
    <script type="text/javascript" src="js/slider.js"></script>
</head>
  <body>
	<div align="Center" >
		<img src="images/JukeBox.png" width="250px" />
	</div>
  
	
	<div id ="menu" align="Center">
		<input type="text" name="Ricerca" size="12" placeholder="Ricerca Brano" border="10" onchange="aggiornaDivElencoBrani(null,null,this)" />
		<a  style="color:white" >Album</a>
		<a href="PaginaCantanti.php">Cantanti</a>
	</div>
	
	<div id="carousel">
	<?php
			include 'connessioneDB.php';
			
			mysqli_select_db($link,"jukeboxsql");
			
			$query = "select * from album";
			$result = mysqli_query($link,$query);
			//ID`, `linkAudio`, `durata`, `linkImg`, `titolo`
			
			while(  $row = mysqli_fetch_object($result)  )
			{
				//<img src="images/brani/coldplay-magic.jpg" id="item-2" ondblclick="window.location.href='index.html'" />  -->
				
				//$target = " window.location.href='indexAlbum.php?id=$row->ID'";
				//echo "<img src='$row->linkImg' id='$row->ID'      ondblclick='$target'    />";
				//echo "<img src='$row->linkImg' id='$row->ID'/>";
				
				echo "<img src='$row->linkImg' id='$row->ID' ondblclick='aggiornaDivElencoBrani($row->ID, null);' width='150px' height='150px' />";
				
				//echo "<img src='$row->linkImg' id='$row->ID' ondblclick='alert(\"$row->linkImg\");'    />";
			}
			mysqli_close($link);
		?>	
   
	</div>

 
	<div id="divElencoBrani" style="color:white">
		Visualizza Brani
	</div>
	<div id="divNomeArtista" style="color:white">
		Nome artista
	</div>
	<div id="divNomeAlbum" style="color:white">
		Nome album
	</div>
	
    <!-- <a href="#" id="prev">Prev</a> | <a href="#" id="next">Next</a> -->

    <br/>

  
    
    </div>

  </body>
</html>

