<?php		
   @include("connessioneDB.php");
	mysqli_select_db($link,"jukeboxsql");
	$idAlbum=$_POST['ID'];
	
	
	
?>

<table class="tabella" >
<tr>
<td><h3>Titolo</h3></td>
<td><h3>Durata</h3></td>
<tr>
<?php
	//CONNESSIONE AL DATABASE

	
	/*$link = mysqli_connect("localhost","root");
	  
	if(mysqli_connect_errno())
	{
		printf("Connessione Fallita");
		exit();
	}*/
	

	

	$query = "SELECT artisti.nome FROM brani join Artisti on CodArtista=artisti.ID WHERE CodAlbum='$idAlbum'" ;
	$result = mysqli_query($link,$query);
	if (!$result) 
	{
		echo "query non eseguita " . mysqli_error();
		exit;
	}

	if (mysqli_num_rows($result) == 0) 
	{
			echo "nessun record trovato";
			exit;
	}
	while ($row = mysqli_fetch_assoc($result)) 
	{
			echo "<tr><td>";
			
			echo "<a href='PaginaBraniArtista.php?idcanzone=".$row["ID"]."'>".$row["titolo"]."</a>"; //
			
			
	}
	
	mysqli_close($link);	
	
?> 
</table>