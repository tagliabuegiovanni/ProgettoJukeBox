<?php		
   @include("connessioneDB.php");
	mysqli_select_db($link,"jukeboxsql");
	$idAlbum="";
	$idArtista="";
	if (isset($_POST['IDAlbum'])) $idAlbum= $_POST['IDAlbum'];
	if (isset($_POST['IDArtista'])) $idArtista=$_POST['IDArtista'];	
	if (isset($_POST['ricerca'])) $ricerca=$_POST['ricerca'];	
?>

<table class="tabella" >
<tr>
<td><h3>Titolo</h3></td>
<td><h3>Durata</h3></td>
<tr>
<?php
	//CONNESSIONE AL DATABASE

	
	/*$link = mysqli_connect("localhost","root");
	  
	if(mysqli_connect_errno())
	{
		printf("Connessione Fallita");
		exit();
	}*/
	

	

	//if(isset($idAlbum) ) 
	//	$query = "SELECT * FROM brani WHERE CodAlbum='$idAlbum'" ;
	//else  if(isset($idArtista) ) 
	//	$query = "SELECT * FROM brani WHERE CodArtista='$idArtista'" ;
	
	
	if ($ricerca=="")
		$query = "SELECT * FROM brani WHERE CodAlbum='$idAlbum' OR CodArtista='$idArtista'" ;
	else 
		$query = "SELECT * FROM brani WHERE  titolo LIKE '%$ricerca%' " ;
	
	$result = mysqli_query($link,$query);
	if (!$result) 
	{
		echo "query non eseguita " . mysqli_error();
		exit;
	}

	if (mysqli_num_rows($result) == 0) 
	{
			echo "nessun record trovato";
			exit;
	}
	while ($row = mysqli_fetch_assoc($result)) 
	{
			echo "<tr><td>";
			
			echo "<a href='AggiungiBraniCoda.php?idcanzone=".$row["ID"]."'>".$row["titolo"]."</a>"; //
			
			$tempo = new DateTime($row["durata"]);
			echo "</td><td>".$tempo->format('i:s')."</td></tr>"; 
			
	}
	
	mysqli_close($link);	
	
?> 
</table>