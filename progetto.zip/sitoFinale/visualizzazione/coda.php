<?php //Elenco brani in coda
	include("connessioneDB.php");
	$query = "SELECT Titolo FROM coda JOIN Brani ON coda.IDBrano=Brani.ID "; //coda
	$query .= " ORDER BY Coda.ID";
	$query .= " LIMIT 1,10";  //Da 1 (salta lo zero/primo che è quello in esecuzione)	
								// a 10 (i primi 10)
	$result = mysqli_query($conn,$query);
	
	if (!$result) 
	{
		echo "div1 query non eseguita " . mysqli_error($conn);
		//exit;
	}

	if (mysqli_num_rows($result) == 0) 
	{
		echo "Nessun brano in coda";
		//exit;
	}
	
	echo "<ol>"; 
	while ($row = mysqli_fetch_assoc($result)) 
	{ 
		echo "<li>".$row['Titolo']."</li>"	;
	}
	echo "</ol>";
?> 