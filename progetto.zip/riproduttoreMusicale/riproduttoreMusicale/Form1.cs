﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace riproduttoreMusicale
{
    public partial class Form1 : Form
    {
       // System.Timers.Timer t1 = new System.Timers.Timer();
        connection c1 = new connection();
        

        public Form1()
        {
            InitializeComponent();
            //timer1.Start();
        }

        

       private void MediaPlayer_Enter(object sender, EventArgs e)
        {
            MediaPlayer.URL = @c1.Ricerca();
           
        }

        private void MediaPlayer_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (MediaPlayer.playState == WMPLib.WMPPlayState.wmppsMediaEnded)
            {
                c1.delete();
                string nextSong = @c1.Ricerca();
                if (nextSong != "")
                {
                    MediaPlayer.URL = nextSong;
                    MediaPlayer.Ctlcontrols.play();
                }
                    
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (MediaPlayer.playState == WMPLib.WMPPlayState.wmppsStopped || MediaPlayer.playState == WMPLib.WMPPlayState.wmppsUndefined || MediaPlayer.playState == WMPLib.WMPPlayState.wmppsReady)
            {
                string nextSong= @c1.Ricerca();
               if (nextSong!="")
                   {
                       MediaPlayer.URL = nextSong;
                       MediaPlayer.Ctlcontrols.play();
                   }
            }
        }

        /*private void MediaPlayer_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {

        }*/
    }
}
