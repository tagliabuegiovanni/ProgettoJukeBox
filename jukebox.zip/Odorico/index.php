<html>
<head>
	<link rel="stylesheet" href="stile.css">
	<title>Jukebox</title>
	
	<script src="jquery-3.0.0.min.js"></script>  <!--Libreria jQuery per metodo load-->
	<script>  
		function aggiorna(){
			
			$( "#divElenco" ).load( "coda.php" );	//Ricarico il div Elenco
			 
			$.get('inEsecuzione.php', function(paginaPhp) {
				 if ($("#divEsecuzione").html()!=paginaPhp)
					$("#divEsecuzione").html( paginaPhp );
			})
		}
		
	</script>
	
</head>
	<body >
	
		<div id="mainDiv">	
			<div id="divElenco"> 
				<!--Elenco brani in coda--> 
			</div> 
				
			<div id="divEsecuzione">
				<!--Brano in esecuzione--> 
			</div> 	 
		</div>
		
		
		<script>setInterval(aggiorna, 2000); //parte il timer per l'aggiornamento </script> 
		
	</body>
</html>