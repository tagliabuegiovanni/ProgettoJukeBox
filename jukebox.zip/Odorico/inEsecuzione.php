<?php //Brano in esecuzione

	include("connessioneDB.php");
	
	$query = "SELECT Titolo FROM coda JOIN Brani ON coda.IDBrano=Brani.ID ";  
	$query .= " LIMIT 1"; //solo la prima, quella in esecuzione
	
	$result = mysqli_query($conn,$query);
	if (!$result) 
	{
		echo "query non eseguita ";
		//exit;
	}

	if (mysqli_num_rows($result) == 0) 
	{
		echo "<marquee>. . .</marquee>";
		//exit;
	} 
	if ($row = mysqli_fetch_assoc($result)) 
	{
		//              ...lascia le virgolette al 3.....
		echo '<marquee scrollamount="3">'.$row["Titolo"]." </marquee>";	
	}
?> 